// ============================================================
// routes/lab-panel.js  — Full CRUD API (Updated)
// Changes: created_by tracking, HOD filter, COE full view,
//          session dropdown support, bulk download endpoint
// ============================================================

module.exports = (promisePool) => {
    const express = require('express');
    const router  = express.Router();

    // ── GET filter data ───────────────────────────────────────────────────────
    router.get('/filter-data', async (req, res) => {
        try {
            const [programmes]    = await promisePool.query(`SELECT programme_id, programme_code, programme_name FROM programme_master WHERE is_active=1 ORDER BY programme_name`);
            const [branches]      = await promisePool.query(`SELECT branch_id, branch_code, branch_name, programme_id FROM branch_master WHERE is_active=1 ORDER BY branch_name`);
            const [semesters]     = await promisePool.query(`SELECT semester_id, semester_name, semester_number FROM semester_master WHERE is_active=1 ORDER BY semester_number`);
            const [sections]      = await promisePool.query(`SELECT section_id, section_name FROM section_master WHERE is_active=1 ORDER BY section_name`);
            const [batches]       = await promisePool.query(`SELECT batch_id, batch_name FROM batch_master WHERE is_active=1 ORDER BY batch_name DESC`);
            const [academicYears] = await promisePool.query(`SELECT academic_year_id, academic_year, semester_type, is_current FROM academic_year_master WHERE is_active=1 ORDER BY academic_year DESC`);
            const [monthYears]    = await promisePool.query(`SELECT month_year_id, display_name, month_name, year_value FROM month_year_master WHERE is_active=1 ORDER BY year_value DESC, month_number ASC`);
            const [colleges]      = await promisePool.query(`SELECT college_id, college_code, college_name FROM college_master WHERE is_active=1 ORDER BY college_name`);
            const [sessions]      = await promisePool.query(`SELECT session_id, session_name, start_time, end_time, session_type, session_group FROM sessions_master WHERE is_active=1 ORDER BY start_time`);

            res.json({ success: true, data: { programmes, branches, semesters, sections, batches, academicYears, monthYears, colleges, sessions } });
        } catch (err) {
            res.status(500).json({ success: false, message: err.message });
        }
    });

    // ── GET practical subjects ────────────────────────────────────────────────
    router.get('/subjects', async (req, res) => {
        const { programme_id, branch_id, semester_id, regulation_id } = req.query;
        if (!programme_id || !branch_id || !semester_id) return res.json({ success: true, data: [] });
        try {
            let sql = `
                SELECT DISTINCT sm.subject_id, sm.syllabus_code, sm.ref_code,
                       sm.subject_name, sm.subject_type, sm.subject_order
                FROM subject_master sm
                WHERE sm.programme_id = ? AND sm.branch_id = ? AND sm.semester_id = ?
                  AND sm.subject_type = 'Practical' AND sm.is_active = 1 AND sm.deleted_at IS NULL`;
            const params = [programme_id, branch_id, semester_id];
            if (regulation_id) { sql += ' AND sm.regulation_id = ?'; params.push(regulation_id); }
            sql += ' ORDER BY sm.subject_order, sm.subject_name';
            const [rows] = await promisePool.query(sql, params);
            res.json({ success: true, data: rows });
        } catch (err) {
            res.status(500).json({ success: false, message: err.message });
        }
    });

    // ── GET allotted internal faculty ─────────────────────────────────────────
    router.get('/allotted-faculty', async (req, res) => {
        const { subject_id, section_id } = req.query;
        try {
            const [allotted] = await promisePool.query(`
                SELECT st.staff_id, st.employee_id, st.full_name, st.title_prefix,
                       st.designation, br.branch_code
                FROM subject_faculty_allotment sfa
                JOIN staff_master st  ON sfa.staff_id     = st.staff_id
                JOIN branch_master br ON st.department_id = br.branch_id
                WHERE sfa.subject_id = ? AND sfa.section_id = ?
                  AND sfa.deleted_at IS NULL AND sfa.is_active = 1
                LIMIT 1
            `, [subject_id, section_id]);

            const [allStaff] = await promisePool.query(`
                SELECT st.staff_id, st.employee_id, st.full_name, st.title_prefix,
                       st.designation, br.branch_code
                FROM staff_master st
                JOIN branch_master br ON st.department_id = br.branch_id
                WHERE st.is_active = 1 AND st.deleted_at IS NULL
                  AND st.employment_status = 'Active'
                  AND (st.college_id IS NULL OR st.college_id = (
                      SELECT college_id FROM college_master WHERE college_code = 'KITSW' LIMIT 1
                  ))
                ORDER BY br.branch_code, st.full_name
            `);

            res.json({ success: true, data: { allotted: allotted[0] || null, all_staff: allStaff } });
        } catch (err) {
            res.status(500).json({ success: false, message: err.message });
        }
    });

    // ── GET search external evaluator ─────────────────────────────────────────
    router.get('/search-external', async (req, res) => {
        const { q, college_id } = req.query;
        if (!q || q.length < 2) return res.json({ success: true, data: [] });
        try {
            let query = `
                SELECT st.staff_id, st.full_name, st.title_prefix, st.designation,
                       st.mobile_number, st.email, st.bank_name, st.ifsc_code,
                       st.account_number, st.pan_card,
                       c.college_id, c.college_code, c.college_name,
                       br.branch_id, br.branch_code, br.branch_name
                FROM staff_master st
                LEFT JOIN college_master c  ON st.college_id    = c.college_id
                LEFT JOIN branch_master br  ON st.department_id = br.branch_id
                WHERE st.is_active = 1 AND st.deleted_at IS NULL
                  AND st.college_id != (SELECT college_id FROM college_master WHERE college_code = 'KITSW' LIMIT 1)
                  AND (st.full_name LIKE ? OR c.college_code LIKE ?)`;
            const params = [`%${q}%`, `%${q}%`];
            if (college_id) { query += ' AND st.college_id = ?'; params.push(college_id); }
            query += ' ORDER BY st.full_name LIMIT 20';
            const [rows] = await promisePool.query(query, params);
            res.json({ success: true, data: rows });
        } catch (err) {
            res.status(500).json({ success: false, message: err.message });
        }
    });

    // ── GET load existing panel ───────────────────────────────────────────────
    router.get('/load', async (req, res) => {
        const { academic_year_id, subject_id, section_id, month_year_id, exam_type } = req.query;
        try {
            const [headers] = await promisePool.query(`
                SELECT h.*, ay.academic_year, ay.semester_type,
                    b.batch_name, p.programme_code, p.programme_name,
                    br.branch_code, br.branch_name,
                    sm.semester_name, sm.semester_number,
                    sub.syllabus_code, sub.subject_name,
                    sec.section_name, my.display_name AS exam_month_display
                FROM lab_panel_header h
                JOIN academic_year_master ay ON h.academic_year_id = ay.academic_year_id
                JOIN batch_master b          ON h.batch_id         = b.batch_id
                JOIN programme_master p      ON h.programme_id     = p.programme_id
                JOIN branch_master br        ON h.branch_id        = br.branch_id
                JOIN semester_master sm      ON h.semester_id      = sm.semester_id
                JOIN subject_master sub      ON h.subject_id       = sub.subject_id
                JOIN section_master sec      ON h.section_id       = sec.section_id
                JOIN month_year_master my    ON h.month_year_id    = my.month_year_id
                WHERE h.academic_year_id=? AND h.subject_id=? AND h.section_id=?
                  AND h.month_year_id=? AND h.exam_type=?
            `, [academic_year_id, subject_id, section_id, month_year_id, exam_type]);

            if (!headers.length) return res.json({ success: true, data: null });
            const header = headers[0];

            const [internal] = await promisePool.query(`
                SELECT li.*, st.staff_id, st.full_name, st.title_prefix,
                       st.employee_id, st.designation, br.branch_code
                FROM lab_panel_internal li
                JOIN staff_master st        ON li.staff_id      = st.staff_id
                LEFT JOIN branch_master br  ON st.department_id = br.branch_id
                WHERE li.panel_id = ?
            `, [header.panel_id]);

            const [externals] = await promisePool.query(`
                SELECT le.*, c.college_name, br.branch_name
                FROM lab_panel_external le
                LEFT JOIN college_master c ON le.college_id = c.college_id
                LEFT JOIN branch_master br ON le.branch_id  = br.branch_id
                WHERE le.panel_id = ? ORDER BY le.slot_no
            `, [header.panel_id]);

            res.json({ success: true, data: { header, internal: internal[0] || null, externals } });
        } catch (err) {
            res.status(500).json({ success: false, message: err.message });
        }
    });

    // ── GET panels list (HOD = own only, COE/Admin = all) ─────────────────────
    router.get('/list', async (req, res) => {
        const { user_id, user_role } = req.query;
        const isCOE = user_role === 'Admin' || user_role === 'Exam_Cell';
        try {
            let sql = `
                SELECT h.panel_id, h.exam_date, h.exam_type, h.status, h.created_by,
                    ay.academic_year, ay.semester_type,
                    br.branch_code, br.branch_name,
                    sm.semester_name, sm.semester_number,
                    sub.syllabus_code, sub.subject_name,
                    sec.section_name, my.display_name AS exam_month,
                    u.username AS created_by_name
                FROM lab_panel_header h
                JOIN academic_year_master ay ON h.academic_year_id = ay.academic_year_id
                JOIN branch_master br        ON h.branch_id        = br.branch_id
                JOIN semester_master sm      ON h.semester_id      = sm.semester_id
                JOIN subject_master sub      ON h.subject_id       = sub.subject_id
                JOIN section_master sec      ON h.section_id       = sec.section_id
                JOIN month_year_master my    ON h.month_year_id    = my.month_year_id
                LEFT JOIN users u            ON h.created_by       = u.user_id`;

            const params = [];
            if (!isCOE && user_id) { sql += ' WHERE h.created_by = ?'; params.push(user_id); }
            sql += ' ORDER BY h.created_at DESC';
            const [rows] = await promisePool.query(sql, params);
            res.json({ success: true, data: rows });
        } catch (err) {
            res.status(500).json({ success: false, message: err.message });
        }
    });

    // ── GET COE dashboard stats ───────────────────────────────────────────────
    router.get('/coe-stats', async (req, res) => {
        const { academic_year_id, semester_ids } = req.query;
        if (!academic_year_id || !semester_ids) {
            return res.json({ success: true, data: { expected: 0, draft: 0, submitted: 0, approved: 0, not_started: 0 } });
        }
        try {
            const semArray = semester_ids.split(',').map(Number).filter(Boolean);
            if (!semArray.length) return res.json({ success: true, data: { expected: 0, draft: 0, submitted: 0, approved: 0, not_started: 0 } });
            const placeholders = semArray.map(() => '?').join(',');

            const [expectedRows] = await promisePool.query(`
                SELECT COUNT(DISTINCT CONCAT(sfa.subject_id, '_', sfa.section_id)) AS expected
                FROM subject_faculty_allotment sfa
                JOIN subject_master sm ON sfa.subject_id = sm.subject_id
                WHERE sm.semester_id IN (${placeholders})
                  AND sm.subject_type = 'Practical' AND sm.is_active = 1 AND sm.deleted_at IS NULL
                  AND sfa.is_active = 1 AND sfa.deleted_at IS NULL
            `, semArray);

            const [statusRows] = await promisePool.query(`
                SELECT h.status, COUNT(*) AS cnt FROM lab_panel_header h
                WHERE h.academic_year_id = ? AND h.semester_id IN (${placeholders})
                GROUP BY h.status
            `, [academic_year_id, ...semArray]);

            const expected = expectedRows[0]?.expected || 0;
            const stats = { draft: 0, submitted: 0, approved: 0 };
            statusRows.forEach(r => { stats[r.status] = r.cnt; });
            const done = stats.draft + stats.submitted + stats.approved;
            res.json({ success: true, data: { expected, draft: stats.draft, submitted: stats.submitted, approved: stats.approved, not_started: Math.max(0, expected - done) } });
        } catch (err) {
            res.status(500).json({ success: false, message: err.message });
        }
    });

    // ── GET COE branch-wise summary ──────────────────────────────────────────
    router.get('/coe-branch-summary', async (req, res) => {
        const { academic_year_id, semester_ids } = req.query;
        if (!academic_year_id || !semester_ids) return res.json({ success: true, data: [] });
        try {
            const semArray = semester_ids.split(',').map(Number).filter(Boolean);
            if (!semArray.length) return res.json({ success: true, data: [] });
            const placeholders = semArray.map(() => '?').join(',');

            const [expRows] = await promisePool.query(`
                SELECT sm.branch_id, COUNT(DISTINCT CONCAT(sfa.subject_id, '_', sfa.section_id)) AS expected
                FROM subject_faculty_allotment sfa
                JOIN subject_master sm ON sfa.subject_id = sm.subject_id
                WHERE sm.semester_id IN (${placeholders})
                  AND sm.subject_type = 'Practical' AND sm.is_active = 1 AND sm.deleted_at IS NULL
                  AND sfa.is_active = 1 AND sfa.deleted_at IS NULL
                GROUP BY sm.branch_id
            `, semArray);
            const expectedMap = {};
            expRows.forEach(r => { expectedMap[r.branch_id] = Number(r.expected); });

            const [panelRows] = await promisePool.query(`
                SELECT br.branch_id, br.branch_code, br.branch_name,
                    SUM(CASE WHEN h.status='submitted' THEN 1 ELSE 0 END) AS submitted,
                    SUM(CASE WHEN h.status='approved'  THEN 1 ELSE 0 END) AS approved,
                    SUM(CASE WHEN h.status='draft'     THEN 1 ELSE 0 END) AS draft,
                    COUNT(h.panel_id) AS total_entered
                FROM lab_panel_header h
                JOIN branch_master br ON h.branch_id = br.branch_id
                WHERE h.academic_year_id = ? AND h.semester_id IN (${placeholders})
                GROUP BY br.branch_id, br.branch_code, br.branch_name ORDER BY br.branch_name
            `, [academic_year_id, ...semArray]);

            const seenBranches = new Set();
            const merged = panelRows.map(r => {
                seenBranches.add(r.branch_id);
                return { branch_id: r.branch_id, branch_code: r.branch_code, branch_name: r.branch_name,
                    expected: expectedMap[r.branch_id] || 0, submitted: Number(r.submitted),
                    approved: Number(r.approved), draft: Number(r.draft),
                    not_started: Math.max(0, (expectedMap[r.branch_id] || 0) - Number(r.total_entered)) };
            });
            for (const [branchId, expected] of Object.entries(expectedMap)) {
                if (!seenBranches.has(Number(branchId)))
                    merged.push({ branch_id: Number(branchId), branch_code: '?', branch_name: '?', expected, submitted: 0, approved: 0, draft: 0, not_started: expected });
            }
            res.json({ success: true, data: merged });
        } catch (err) {
            res.status(500).json({ success: false, message: err.message });
        }
    });

    // ── GET COE panel list with filters ───────────────────────────────────────
    router.get('/coe-list', async (req, res) => {
        const { academic_year_id, semester_ids, status } = req.query;
        if (!academic_year_id) return res.json({ success: true, data: [] });
        try {
            const semArray = semester_ids ? semester_ids.split(',').map(Number).filter(Boolean) : [];
            const placeholders = semArray.length ? semArray.map(() => '?').join(',') : null;

            let sql = `
                SELECT h.panel_id, h.exam_date, h.exam_type, h.status, h.created_by,
                    h.exam_time_from, h.exam_time_to,
                    ay.academic_year, ay.semester_type,
                    br.branch_code, br.branch_name,
                    sm.semester_name, sm.semester_number,
                    sub.syllabus_code, sub.subject_name, sub.ref_code,
                    sec.section_name, my.display_name AS exam_month,
                    u.username AS created_by_name,
                    li_st.full_name AS internal_name, li_st.title_prefix AS internal_prefix
                FROM lab_panel_header h
                JOIN academic_year_master ay ON h.academic_year_id = ay.academic_year_id
                JOIN branch_master br        ON h.branch_id        = br.branch_id
                JOIN semester_master sm      ON h.semester_id      = sm.semester_id
                JOIN subject_master sub      ON h.subject_id       = sub.subject_id
                JOIN section_master sec      ON h.section_id       = sec.section_id
                JOIN month_year_master my    ON h.month_year_id    = my.month_year_id
                LEFT JOIN users u            ON h.created_by       = u.user_id
                LEFT JOIN lab_panel_internal li ON h.panel_id      = li.panel_id
                LEFT JOIN staff_master li_st    ON li.staff_id     = li_st.staff_id
                WHERE h.academic_year_id = ?`;

            const params = [academic_year_id];
            if (placeholders) { sql += ` AND h.semester_id IN (${placeholders})`; params.push(...semArray); }
            if (status && status !== 'all') { sql += ' AND h.status = ?'; params.push(status); }
            sql += ' ORDER BY br.branch_name, sm.semester_number, sub.subject_name, sec.section_name';

            const [rows] = await promisePool.query(sql, params);
            res.json({ success: true, data: rows });
        } catch (err) {
            res.status(500).json({ success: false, message: err.message });
        }
    });

    // ── GET HOD bulk download ─────────────────────────────────────────────────
    // Returns all submitted/approved panels for a HOD scoped to their branch,
    // for a given academic year + semester + exam month, with full
    // internal evaluator and all 3 external evaluator details attached.
    // Frontend groups by semester → branch and renders print layout.
    router.get('/download', async (req, res) => {
        const { user_id, academic_year_id, semester_id, month_year_id } = req.query;
        if (!user_id || !academic_year_id || !semester_id || !month_year_id) {
            return res.status(400).json({ success: false, message: 'user_id, academic_year_id, semester_id and month_year_id are required' });
        }
        try {
            // Fetch all matching panel headers
            const [headers] = await promisePool.query(`
                SELECT
                    h.panel_id, h.exam_date, h.exam_time_from, h.exam_time_to,
                    h.exam_type, h.status, h.created_at, h.approved_at,
                    ay.academic_year, ay.semester_type,
                    b.batch_name,
                    p.programme_code, p.programme_name,
                    br.branch_code, br.branch_name, br.branch_id,
                    sm.semester_name, sm.semester_number, sm.semester_id,
                    sub.syllabus_code, sub.ref_code, sub.subject_name,
                    sec.section_name,
                    my.display_name AS exam_month_display,
                    col.college_name, col.college_code
                FROM lab_panel_header h
                JOIN academic_year_master ay ON h.academic_year_id = ay.academic_year_id
                JOIN batch_master b          ON h.batch_id         = b.batch_id
                JOIN programme_master p      ON h.programme_id     = p.programme_id
                JOIN branch_master br        ON h.branch_id        = br.branch_id
                JOIN semester_master sm      ON h.semester_id      = sm.semester_id
                JOIN subject_master sub      ON h.subject_id       = sub.subject_id
                JOIN section_master sec      ON h.section_id       = sec.section_id
                JOIN month_year_master my    ON h.month_year_id    = my.month_year_id
                LEFT JOIN college_master col ON col.college_code   = 'KITSW'
                WHERE h.created_by       = ?
                  AND h.academic_year_id = ?
                  AND h.semester_id      = ?
                  AND h.month_year_id    = ?
                  AND h.status IN ('submitted', 'approved')
                ORDER BY br.branch_name, sub.subject_name, sec.section_name
            `, [user_id, academic_year_id, semester_id, month_year_id]);

            if (!headers.length) return res.json({ success: true, data: [] });

            const panelIds    = headers.map(h => h.panel_id);
            const ph          = panelIds.map(() => '?').join(',');

            const [internals] = await promisePool.query(`
                SELECT li.panel_id, li.is_allotted,
                       st.staff_id, st.full_name, st.title_prefix,
                       st.employee_id, st.designation,
                       br.branch_code, br.branch_name
                FROM lab_panel_internal li
                JOIN staff_master st        ON li.staff_id      = st.staff_id
                LEFT JOIN branch_master br  ON st.department_id = br.branch_id
                WHERE li.panel_id IN (${ph})
            `, panelIds);

            const [externals] = await promisePool.query(`
                SELECT le.*,
                       c.college_name  AS college_name_master,
                       br.branch_name  AS branch_name_master
                FROM lab_panel_external le
                LEFT JOIN college_master c ON le.college_id = c.college_id
                LEFT JOIN branch_master br ON le.branch_id  = br.branch_id
                WHERE le.panel_id IN (${ph})
                ORDER BY le.panel_id, le.slot_no
            `, panelIds);

            // Map onto headers
            const internalMap = {};
            internals.forEach(i => { internalMap[i.panel_id] = i; });
            const externalMap = {};
            externals.forEach(e => {
                if (!externalMap[e.panel_id]) externalMap[e.panel_id] = [];
                externalMap[e.panel_id].push(e);
            });

            const result = headers.map(h => ({
                ...h,
                internal:  internalMap[h.panel_id] || null,
                externals: externalMap[h.panel_id] || []
            }));

            res.json({ success: true, data: result });
        } catch (err) {
            res.status(500).json({ success: false, message: err.message });
        }
    });

    // ── POST save panel ───────────────────────────────────────────────────────
    router.post('/save', async (req, res) => {
        const conn = await promisePool.getConnection();
        try {
            await conn.beginTransaction();
            const { header, internal, externals } = req.body;

            if (header.panel_id) {
                const [existing] = await conn.query(`SELECT status FROM lab_panel_header WHERE panel_id = ?`, [header.panel_id]);
                if (existing.length > 0 && existing[0].status === 'approved') {
                    await conn.rollback();
                    return res.status(403).json({ success: false, message: 'Panel approved by COE. Editing not allowed.' });
                }
            }

            let panel_id = header.panel_id || null;
            if (panel_id) {
                await conn.query(`
                    UPDATE lab_panel_header SET
                        academic_year_id=?, batch_id=?, programme_id=?, branch_id=?,
                        semester_id=?, subject_id=?, section_id=?, month_year_id=?,
                        exam_type=?, exam_date=?, exam_time_from=?, exam_time_to=?, status='draft'
                    WHERE panel_id=?
                `, [header.academic_year_id, header.batch_id, header.programme_id, header.branch_id,
                    header.semester_id, header.subject_id, header.section_id, header.month_year_id,
                    header.exam_type, header.exam_date||null, header.exam_time_from||null, header.exam_time_to||null, panel_id]);
            } else {
                const [ins] = await conn.query(`
                    INSERT INTO lab_panel_header
                        (academic_year_id, batch_id, programme_id, branch_id, semester_id,
                         subject_id, section_id, month_year_id, exam_type,
                         exam_date, exam_time_from, exam_time_to, status, created_by)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'draft',?)
                `, [header.academic_year_id, header.batch_id, header.programme_id, header.branch_id,
                    header.semester_id, header.subject_id, header.section_id, header.month_year_id,
                    header.exam_type, header.exam_date||null, header.exam_time_from||null, header.exam_time_to||null,
                    header.created_by || null]);
                panel_id = ins.insertId;
            }

            if (internal && internal.staff_id) {
                await conn.query(`DELETE FROM lab_panel_internal WHERE panel_id=?`, [panel_id]);
                await conn.query(`INSERT INTO lab_panel_internal (panel_id, staff_id, is_allotted) VALUES (?,?,?)`,
                    [panel_id, internal.staff_id, internal.is_allotted ? 1 : 0]);
            }

            if (externals && externals.length > 0) {
                await conn.query(`DELETE FROM lab_panel_external WHERE panel_id=?`, [panel_id]);
                for (const ext of externals) {
                    if (!ext.full_name) continue;
                    let staff_id = ext.staff_id || null;
                    if (!staff_id && ext.full_name) {
                        const [existing] = await conn.query(`SELECT staff_id FROM staff_master WHERE full_name=? AND college_id=? LIMIT 1`, [ext.full_name, ext.college_id || null]);
                        if (existing.length > 0) {
                            staff_id = existing[0].staff_id;
                            await conn.query(`
                                UPDATE staff_master SET
                                    designation=COALESCE(?,designation), mobile_number=COALESCE(?,mobile_number),
                                    email=COALESCE(?,email), bank_name=COALESCE(?,bank_name),
                                    ifsc_code=COALESCE(?,ifsc_code), account_number=COALESCE(?,account_number),
                                    pan_card=COALESCE(?,pan_card), department_id=COALESCE(?,department_id)
                                WHERE staff_id=?
                            `, [ext.designation||null, ext.mobile_number||null, ext.email||null,
                                ext.bank_name||null, ext.ifsc_code||null, ext.account_number||null,
                                ext.pan_card||null, ext.branch_id||null, staff_id]);
                        } else {
                            const [newStaff] = await conn.query(`
                                INSERT INTO staff_master (college_id, employee_id, title_prefix, full_name, department_id,
                                     designation, mobile_number, email, bank_name, ifsc_code,
                                     account_number, pan_card, employment_status, is_active)
                                VALUES (?,NULL,?,?,?,?,?,?,?,?,?,?,'Active',1)
                            `, [ext.college_id||null, ext.title_prefix||'Dr', ext.full_name,
                                ext.branch_id||null, ext.designation||'Professor',
                                ext.mobile_number||null, ext.email||null, ext.bank_name||null,
                                ext.ifsc_code||null, ext.account_number||null, ext.pan_card||null]);
                            staff_id = newStaff.insertId;
                        }
                    }
                    await conn.query(`
                        INSERT INTO lab_panel_external
                            (panel_id, slot_no, staff_id, college_id, college_code_text,
                             full_name, designation, branch_text, branch_id,
                             email, mobile_number, bank_name, ifsc_code, account_number, pan_card)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    `, [panel_id, ext.slot_no, staff_id, ext.college_id||null, ext.college_code_text||null,
                        ext.full_name, ext.designation||null, ext.branch_text||null, ext.branch_id||null,
                        ext.email||null, ext.mobile_number||null, ext.bank_name||null,
                        ext.ifsc_code||null, ext.account_number||null, ext.pan_card||null]);
                }
            }

            await conn.commit();
            res.json({ success: true, message: 'Panel saved successfully', panel_id });
        } catch (err) {
            await conn.rollback();
            res.status(500).json({ success: false, message: err.message });
        } finally {
            conn.release();
        }
    });

    // ── POST submit to COE ────────────────────────────────────────────────────
    router.post('/:id/submit', async (req, res) => {
        try {
            const [panel] = await promisePool.query(`SELECT status FROM lab_panel_header WHERE panel_id=?`, [req.params.id]);
            if (!panel.length) return res.status(404).json({ success: false, message: 'Panel not found' });
            if (panel[0].status === 'approved') return res.status(403).json({ success: false, message: 'Already approved by COE' });
            await promisePool.query(`UPDATE lab_panel_header SET status='submitted' WHERE panel_id=?`, [req.params.id]);
            res.json({ success: true, message: 'Panel submitted to COE successfully' });
        } catch (err) {
            res.status(500).json({ success: false, message: err.message });
        }
    });

    // ── POST COE approve ──────────────────────────────────────────────────────
    router.post('/:id/approve', async (req, res) => {
        const conn = await promisePool.getConnection();
        try {
            await conn.beginTransaction();
            const { selected_external_id, internal_staff_id, approved_by } = req.body;
            const panel_id = req.params.id;
            await conn.query(`UPDATE lab_panel_external SET is_coe_selected=0 WHERE panel_id=?`, [panel_id]);
            if (selected_external_id)
                await conn.query(`UPDATE lab_panel_external SET is_coe_selected=1 WHERE external_id=? AND panel_id=?`, [selected_external_id, panel_id]);
            if (internal_staff_id)
                await conn.query(`UPDATE lab_panel_internal SET staff_id=? WHERE panel_id=?`, [internal_staff_id, panel_id]);
            await conn.query(`UPDATE lab_panel_header SET status='approved', approved_by=?, approved_at=NOW() WHERE panel_id=?`, [approved_by || null, panel_id]);
            await conn.commit();
            res.json({ success: true, message: 'Panel approved successfully' });
        } catch (err) {
            await conn.rollback();
            res.status(500).json({ success: false, message: err.message });
        } finally {
            conn.release();
        }
    });

    // ── POST COE send back to HOD ─────────────────────────────────────────────
    router.post('/:id/sendback', async (req, res) => {
        try {
            const { remark } = req.body;
            await promisePool.query(`UPDATE lab_panel_header SET status='draft', sendback_remark=? WHERE panel_id=? AND status='submitted'`, [remark || null, req.params.id]);
            res.json({ success: true, message: 'Panel sent back to HOD' });
        } catch (err) {
            res.status(500).json({ success: false, message: err.message });
        }
    });

    // ── GET single panel by id ────────────────────────────────────────────────
    router.get('/:id', async (req, res) => {
        try {
            const [headers] = await promisePool.query(`
                SELECT h.*, ay.academic_year, ay.semester_type,
                    b.batch_name, p.programme_code, p.programme_name,
                    br.branch_code, br.branch_name,
                    sm.semester_name, sm.semester_number,
                    sub.syllabus_code, sub.subject_name, sub.ref_code,
                    sec.section_name, my.display_name AS exam_month_display
                FROM lab_panel_header h
                JOIN academic_year_master ay ON h.academic_year_id = ay.academic_year_id
                JOIN batch_master b          ON h.batch_id         = b.batch_id
                JOIN programme_master p      ON h.programme_id     = p.programme_id
                JOIN branch_master br        ON h.branch_id        = br.branch_id
                JOIN semester_master sm      ON h.semester_id      = sm.semester_id
                JOIN subject_master sub      ON h.subject_id       = sub.subject_id
                JOIN section_master sec      ON h.section_id       = sec.section_id
                JOIN month_year_master my    ON h.month_year_id    = my.month_year_id
                WHERE h.panel_id=?
            `, [req.params.id]);

            if (!headers.length) return res.status(404).json({ success: false, message: 'Not found' });

            const [internal] = await promisePool.query(`
                SELECT li.*, st.full_name, st.title_prefix, st.employee_id,
                       st.designation, br.branch_code
                FROM lab_panel_internal li
                JOIN staff_master st        ON li.staff_id      = st.staff_id
                LEFT JOIN branch_master br  ON st.department_id = br.branch_id
                WHERE li.panel_id=?
            `, [req.params.id]);

            const [externals] = await promisePool.query(`
                SELECT le.*, c.college_name, br.branch_name
                FROM lab_panel_external le
                LEFT JOIN college_master c ON le.college_id = c.college_id
                LEFT JOIN branch_master br ON le.branch_id  = br.branch_id
                WHERE le.panel_id=? ORDER BY le.slot_no
            `, [req.params.id]);

            res.json({ success: true, data: { header: headers[0], internal: internal[0] || null, externals } });
        } catch (err) {
            res.status(500).json({ success: false, message: err.message });
        }
    });

    return router;
};
